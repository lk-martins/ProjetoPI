package br.edu.ifrn.crud.controladores;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.edu.ifrn.crud.dominio.Arquivo;
import br.edu.ifrn.crud.dominio.Categoria;
import br.edu.ifrn.crud.dominio.Usuario;
import br.edu.ifrn.crud.dto.AutocompleteDTO;
import br.edu.ifrn.crud.repository.ArquivoRepository;
import br.edu.ifrn.crud.repository.CategoriaRepository;
import br.edu.ifrn.crud.repository.UsuarioRepository;

@Controller
@RequestMapping("/usuarios")
public class CadastroUsuarioController {

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Autowired
	private CategoriaRepository categoriaRepository;

	@Autowired
	private ArquivoRepository arquivoRepository;

	@GetMapping("/cadastro")
	public String entrarCadastro(ModelMap model) {
		model.addAttribute("usuario", new Usuario());

		return "usuario/cadastro";
	}

	@PostMapping("/salvar")
	@Transactional(readOnly = false)
	public String salvar(Usuario usuario, ModelMap model, RedirectAttributes attr,
			@RequestParam("file") MultipartFile arquivo, HttpSession sessao) {

		List<String> msgValidacao = validarDados(usuario);

		if (!msgValidacao.isEmpty()) {
			model.addAttribute("msgErro", msgValidacao);
			return "usuario/cadastro";
		}

		try {
			if (arquivo != null && !arquivo.isEmpty()) {
				// Normalizando o nome do arquivo
				String nomeArquivo = StringUtils.cleanPath(arquivo.getOriginalFilename());

				Arquivo arquivoBD = new Arquivo(null, nomeArquivo, arquivo.getContentType(), arquivo.getBytes());

				// Salvando a foto no BD
				arquivoRepository.save(arquivoBD);

				if (usuario.getFoto() != null && usuario.getFoto().getId() != null && usuario.getFoto().getId() > 0) {
					arquivoRepository.delete(usuario.getFoto());
				}

				usuario.setFoto(arquivoBD);

			} else {
				usuario.setFoto(null);
			}
			
			//Criptografando senha
			String senhaCriptografada = new BCryptPasswordEncoder().encode(usuario.getSenha());
			usuario.setSenha(senhaCriptografada);

			usuarioRepository.save(usuario);
			attr.addFlashAttribute("msgSucesso", "Operação realizada com sucesso!");
		} catch (IOException e) {
			e.printStackTrace();
		}

		return "redirect:/usuarios/cadastro";
	}

	@GetMapping("/editar/{id}")
	public String iniciarEdicao(@PathVariable("id") Integer idUsuario, ModelMap model, HttpSession sessao) {

		Usuario u = usuarioRepository.findById(idUsuario).get();

		model.addAttribute("usuario", u);
		return "usuario/cadastro";
	}

	@GetMapping("/autocompleteCategorias")
	@Transactional(readOnly = true)
	@ResponseBody
	public List<AutocompleteDTO> autocompleteCategorias(@RequestParam("term") String termo) {

		List<Categoria> categorias = categoriaRepository.findByNome(termo);

		List<AutocompleteDTO> resultados = new ArrayList<>();

		categorias.forEach(c -> resultados.add(new AutocompleteDTO(c.getNome(), c.getId())));

		return resultados;
	}

	private List<String> validarDados(Usuario usuario) {
		List<String> msgs = new ArrayList<>();

		if (usuario.getNome() == null || usuario.getNome().isEmpty())
			msgs.add("O campo nome é obrigatório.");

		if (usuario.getEmail() == null || usuario.getEmail().isEmpty())
			msgs.add("O campo email é obrigatório.");

		return msgs;
	}
}
