package br.edu.ifrn.crud.controladores;

import java.util.List;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.edu.ifrn.crud.dominio.Horario;
import br.edu.ifrn.crud.repository.HorarioRepository;

@Controller
@RequestMapping("/horarios")
public class BuscaHorarioController {

	@Autowired
	private HorarioRepository horarioRepository;

	@GetMapping("/busca")
	public String entrarBusca() {
		return "usuario/buscahorario";
	}

	@GetMapping("/buscar")
	public String buscar(@RequestParam(name = "nome", required = false) String nome,
			@RequestParam(name = "mostrarTodosDados", required = false) Boolean mostrarTodosDados, HttpSession sessao,
			ModelMap model) {

		List<Horario> horariosEncontrados = horarioRepository.findByNome(nome);

		model.addAttribute("horariosEncontrados", horariosEncontrados);

		if (mostrarTodosDados != null) {
			model.addAttribute("mostrarTodosDados", true);
		}

		return "usuario/buscahorario";
	}

	@GetMapping("/remover/{id}")
	public String remover(@PathVariable("id") Integer idHorario, HttpSession sessao, RedirectAttributes attr) {

		horarioRepository.deleteById(idHorario);
		attr.addFlashAttribute("msgSucesso", "Usuário removido com sucesso!");
		
		return "redirect:/horarios/buscar";
	}
}
