package br.edu.ifrn.crud.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.edu.ifrn.crud.dominio.Horario;

public interface HorarioRepository extends JpaRepository<Horario, Integer> {

	@Query("select h from Horario h where h.nome like %:nome%")
	List<Horario> findByNome(@Param("nome") String nome);

}
