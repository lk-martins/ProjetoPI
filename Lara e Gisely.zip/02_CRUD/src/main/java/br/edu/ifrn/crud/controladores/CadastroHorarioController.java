package br.edu.ifrn.crud.controladores;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.edu.ifrn.crud.dominio.Horario;
import br.edu.ifrn.crud.repository.HorarioRepository;

@Controller
@RequestMapping("/horarios")
public class CadastroHorarioController {
	
	@Autowired
	private HorarioRepository horarioRepository;

	@GetMapping("/cadastro")
	public String entrarCadastro(ModelMap model) {
		model.addAttribute("horario", new Horario());

		return "usuario/cadhorario";
	}

	@PostMapping("/salvar")
	public String salvar(Horario horario, ModelMap model, RedirectAttributes attr, HttpSession sessao) {

		List<String> msgValidacao = validarDados(horario);

		if (!msgValidacao.isEmpty()) {
			model.addAttribute("msgErro", msgValidacao);
			return "usuario/cadhorario";
		}
		
		horarioRepository.save(horario);
		attr.addFlashAttribute("msgSucesso", "Operação realizada com sucesso!");

		return "redirect:/horarios/cadastro";
	}

	@GetMapping("/editar/{id}")
	public String iniciarEdicao(@PathVariable("id") Integer idHorario, ModelMap model, HttpSession sessao) {

		Horario h = horarioRepository.findById(idHorario).get();

		model.addAttribute("horario", h);
		return "usuario/cadhorario";
	}

	@ModelAttribute("horas")
	public List<String> getHoras() {
		return Arrays.asList("8h", "9h", "10h", "11h", "12h", "13h");
	}

	private List<String> validarDados(Horario horario) {
		List<String> msgs = new ArrayList<>();

		if (horario.getNome() == null || horario.getNome().isEmpty())
			msgs.add("O campo nome é obrigatório.");

		if (horario.getDia() == null || horario.getDia().isEmpty())
			msgs.add("O campo email é obrigatório.");

		if (horario.getHora() == null || horario.getHora().isEmpty())
			msgs.add("O campo sexo é obrigatório.");

		return msgs;
	}
}
